/* Name: Sam Lite and Akshay Kumar
 * netID: slite@ and aktwo@
 * Precept: P04 (Maia Ginsburg) and P02 (Diego Botera)
 * Assignment: 2 - Deques and Randomized Queues
 * Description: Checks to see whether an input string is a
 *   Watson-Crick palindrome
 * Compilation: javac Palindrome.java
 * Execution: echo ACACTGTG | java Palindrome
 * Dependencies: StdIn, Deque
 */

public class Palindrome {
    
    public static void main(String[] args)
    {
        boolean isItAPalindrome = false;
        Deque<Character> d = new Deque<Character>();
        boolean broken = false;
        
        // read in each character in from standard input
        while (!StdIn.isEmpty() && !broken) {
            char c = StdIn.readChar();
            
            // check to see whether or not the input characters are 
            // in the proper format, otherwise break and return false
            if (!(c == 'A' || c == 'C' || c == 'G' || c == 'T')) {
                System.out.println(isItAPalindrome);
                broken = true;
            }
            d.addLast(c);
        }
        
        // remove corner case if there are an odd number of characters 
        // entered
        if (d.size() % 2 == 1 && !broken) {
            System.out.println(isItAPalindrome);
            broken = true;
        }
        
        // systematically remove one character from the front and the back
        // and check whether or not they are complements
        while (!d.isEmpty() && !broken) {
            char first = d.removeFirst();
            char last = d.removeLast();
            if (!isComplement(first, last)) {
                System.out.println(isItAPalindrome);
                broken = true;
            }
        }
        
        // if all character pairs are complements, then the input
        // is a palindrome
        if (!broken) isItAPalindrome = true;
        if (isItAPalindrome) System.out.println(isItAPalindrome);
    }
    
    // helper method to check whether two gene markers are complements
    private static boolean isComplement(char a, char b) {
        if (a == 'T' && b == 'A') return true;
        else if (a == 'A' && b == 'T') return true;
        else if (a == 'C' && b == 'G') return true;
        else if (a == 'G' && b == 'C') return true;
        return false;
    }
}