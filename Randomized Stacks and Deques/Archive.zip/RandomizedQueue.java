/* Name: Sam Lite and Akshay Kumar
 * netID: slite@ and aktwo@
 * Precept: P04 (Maia Ginsburg) and P02 (Diego Botera)
 * Assignment: 2 - Deques and Randomized Queues
 * Description: Implements and tests a RandomizedQueue data type
 * Compilation: javac RandomizedQueue.java
 * Execution (runs test method): java RandomizedQueue
 * Dependencies: StdRandom
 */


import java.util.NoSuchElementException;
import java.util.Iterator;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] q;  // resizing array, holds items
    private int N = 0; // number of items in array
    
    // construct an empty randomized queue
    public RandomizedQueue()           
    {
        q = (Item[]) new Object[1];
    }
    
    // is the queue empty?
    public boolean isEmpty()           
    {
        return N == 0;
    }
    
    // return the number of items on the queue
    public int size()                  
    {
        return N;
    }
    
    // helper method to resize an array to a specified capacity
    private void resize(int capacity)
    {
        Item[] copy = (Item[]) new Object[capacity];
        for (int i = 0; i < N; i++) 
            copy[i] = q[i];
        q = copy;
    }
    
    // add the item
    public void enqueue(Item item)    
    {
        if (item == null) 
            throw new NullPointerException("can't add null item");
        
        //resize if necessary
        if (N == this.q.length) this.resize(2 * this.q.length);
        
        this.q[N] = item;
        N++;
    }
    
    // delete and return a random item
    public Item dequeue()  
    {
        if (this.isEmpty()) 
            throw new NoSuchElementException("queue is empty");
        
        // shuffle non-null array elements, return last non-null element
        StdRandom.shuffle(q, 0, N - 1);
        Item toReturn = q[N - 1];
        q[N - 1] = null;
        N--;
        
        //resize if necessary
        if (N > 0 && N == q.length / 4)
            resize(q.length / 2);
        
        return toReturn;
    }
    
    // return (but do not delete) a random item
    public Item sample()               
    {
        if (this.isEmpty()) 
            throw new NoSuchElementException("queue is empty");
        int randIndex = StdRandom.uniform(N);
        return q[randIndex];
    }
    
    // return an independent iterator over items in random order
    public Iterator<Item> iterator()   
    {
        return new RQIterator();
    }
    
    // private class to implement the methods of the Iterable interface
    private class RQIterator implements Iterator<Item> {
        private int i = 0;
        private Item[] shuffledCopy;
        
        private RQIterator() {
            shuffledCopy = (Item[]) new Object[q.length];
            for (int j = 0; j < q.length; j++)
                shuffledCopy[j] = q[j];
        }
        
        public boolean hasNext() {
            return i < N;
        }
        public void remove() {
            throw new UnsupportedOperationException();
        }
        public Item next() {
            if (!hasNext())
                throw new NoSuchElementException();
            
            // shuffle remaining portion of array, return next element
            StdRandom.shuffle(shuffledCopy, i, N-1);
            i++;
            return shuffledCopy[i-1];
        }
    }
    
    // helper method for the test method
    private int getArrayLength() { 
        return this.q.length;
    }
    
    // test method
    public static void main(String[] args)
    {
        RandomizedQueue<String> rq = new RandomizedQueue<String>();
        
        // make sure exceptions are caught
        try { rq.dequeue(); }
        catch (Exception e) { System.out.println("caught!"); }
        
        try { rq.enqueue(null); }
        catch (Exception e) { System.out.println("caught!"); }
        
        // enqueue 9 items, checking if resizing is successful
        for (int i = 0; i < 9; i++) {
            rq.enqueue("newItem " + i);
            System.out.println("enqueue: " + "newItem " + i);
            System.out.println("N:       " + rq.size());
            System.out.println("length   " + rq.getArrayLength());
            for (String s : rq) {
                System.out.print(s + " ");
            }
            System.out.println();
            System.out.println("------------------");
        }
                
        // test iterator
        for (String s : rq) {
            for (String t : rq)
            {
                System.out.print(s + " ");   
                System.out.print(t + " ");
                System.out.println();
            }
        }
        
        //dequeue and print out, checking if resizing is successful
        for (int i = 0; i < 9; i++) {
            System.out.println("dequeue: " + rq.dequeue());
            System.out.println("N:       " + rq.size());
            System.out.println("length   " + rq.getArrayLength());
            for (String s : rq) {
                System.out.print(s + " ");
            }
            System.out.println();
            System.out.println("------------------");
        }
    }
}
