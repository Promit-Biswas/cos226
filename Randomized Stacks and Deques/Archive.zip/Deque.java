/* Name: Sam Lite and Akshay Kumar
 * netID: slite@ and aktwo@
 * Precept: P04 (Maia Ginsburg) and P02 (Diego Botera)
 * Assignment: 2 - Deques and Randomized Queues
 * Description: Implements and tests a Deque data type
 * Execution (runs test method): java Deque
 * Compilation: javac Deque.java
 * Dependencies: None
 */

import java.util.NoSuchElementException;
import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {
    private Node first; // first node in linked list
    private Node last;  // last item in linked list
    private int N;      // number of items in deque
    
    // private helper class
    private class Node {
        private Item item;
        private Node next;
        private Node previous;
    }
    
    // construct an empty deque
    public Deque() {
        N = 0;
    }
    
    // is the deque empty?
    public boolean isEmpty() {          
        return N == 0;
    }
    
    // return the number of items on the deque
    public int size() {                 
        return N;
    }
    
    // insert the item at the front
    public void addFirst(Item item) {
        if (item == null) 
            throw new NullPointerException("can't add null item");
        
        Node oldFirst = first;
        first = new Node();
        first.item = item;
        if (this.size() == 0) {  // special case for first item added
            last = first;
        }
        else { 
            first.next = oldFirst;
            oldFirst.previous = first;
        }
        N++;
    }
    
    // insert the item at the end
    public void addLast(Item item) {
        if (item == null) 
            throw new NullPointerException("can't add null item");
        
        // special case, deque is empty
        if (this.size() == 0) { addFirst(item); }
        else {
            Node oldLast = last;
            last = new Node();
            last.item = item;
            oldLast.next = last;
            last.previous = oldLast;
            N++;
        }
        
    }
    
    // delete and return the item at the front
    public Item removeFirst() {
        if (this.isEmpty()) 
            throw new NoSuchElementException("deque is empty");
        
        Item toReturn;
        
        //special case, only one item in deque left
        if (this.size() == 1) {
            toReturn = first.item;
            first = first.next;
            last = first;
        }
        else {
            if (this.size() == 2) { last.previous = null; }
            toReturn = first.item;
            first = first.next;
        }
        N--;
        return toReturn;
    }
    
    // delete and return the item at the end
    public Item removeLast() {
        if (this.isEmpty()) 
            throw new NoSuchElementException("deque is empty");
        
        //special case, only one item in deque left
        if (this.size() == 1) {
            return this.removeFirst();
        }
        else {
            Node newLast = last.previous;
            Item toReturn = last.item;
            last.previous = null;
            last = newLast;
            last.next = null;
            N--;
            return toReturn;
            
        }
        
    }
    
    // return an iterator over items in order from front to end
    public Iterator<Item> iterator()  { return new DequeIterator();  }
    
    // an iterator, doesn't implement remove() since it's optional
    private class DequeIterator implements Iterator<Item> {
        private Node current = first;
        
        // check to see if the iterator object has another item
        public boolean hasNext() {
            return current != null;
        }
        
        // unsupported method, not implemented
        public void remove() {
            throw new UnsupportedOperationException();
        }
        
        // returns next item in the Deque
        public Item next() {
            if (!hasNext())
                throw new NoSuchElementException();
            Item item = current.item;
            current = current.next;
            return item;
        }
    }
    
    
    // test method
    public static void main(String[] args)
    {
        Deque<String> d = new Deque<String>();
        
        // make sure exceptions are caught
        try { d.removeFirst(); }
        catch (Exception e) { System.out.println("caught!"); }
        
        try { d.removeLast(); }
        catch (Exception e) { System.out.println("caught!"); }
        
        try { d.addFirst(null); }
        catch (Exception e) { System.out.println("caught!"); }
        
        try { d.addLast(null); }
        catch (Exception e) { System.out.println("caught!"); }
        
        // randomly call add and remove methods and then check size
        for (int i = 0; i < 200; i++) {
            double x = Math.random();
            
            if (x < .25) {
                System.out.println("addfirst    " + i);
                d.addFirst("" + i);
            }
            else if (x < .5) {
                System.out.println("addlast     " + i);
                d.addLast("" + i);
            }
            else if (x < .75) {
                System.out.println("removefirst");
                try { d.removeFirst(); }
                catch (Exception e) { System.out.println("caught!"); }
            }
            else {
                System.out.println("removelast ");
                try { d.removeLast(); }
                catch (Exception e) { System.out.println("caught!"); }
            }
            System.out.println("size: " + d.size());
        }
        
        // test iterator
        for (String s : d) {
            for (String t: d) {
                System.out.println(s + " " + t);
            }
        }
        
    }
}
