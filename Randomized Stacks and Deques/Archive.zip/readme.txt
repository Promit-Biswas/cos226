/**********************************************************************
 *  Randomized Queues and Deques
 **********************************************************************/

Name: Akshay Kumar
Login: aktwo
Precept: P02

Partner name: Sam Lite
Parner login: slite
Partner precept: P04

Hours to complete assignment (optional): 10


/**********************************************************************
 *  Explain briefly how you implemented the randomized queue and deque.
 *  Which data structure did you choose (array, linked list, etc.)
 *  and why?
 **********************************************************************/

We used a linked list for the Deque to ensure worst case constant-time
performance. We used a resizing array for the randomized queue to 
facilitate the random selection of array indices to "sample" and 
randomly dequeue elements.

/**********************************************************************
 *  Known bugs / limitations.
 **********************************************************************/

N/A

/**********************************************************************
 *  Describe whatever help (if any) that you received.
 *  Don't include readings, lectures, and precepts, but do
 *  include any help from people (including course staff, lab TAs,
 *  classmates, and friends) and attribute them by name.
 **********************************************************************/

N/A

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

Lot of issues dealing with pointers in our linked list, but we
figured it out eventually :)

/**********************************************************************
 *  If you worked with a partner, assert below that you followed
 *  the protocol as described on the assignment page. Give one
 *  sentence explaining what each of you contributed.
 **********************************************************************/

We wrote both of the programs together, alternating between writing
and looking over the other's shoulder. We followed the same protocol 
through the debugging and style cleanup phases.

/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **********************************************************************/
